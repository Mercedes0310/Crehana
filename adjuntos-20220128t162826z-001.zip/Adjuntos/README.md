# Curso_Intro_AI_Crehana
Repositorio del Curso de Introducción a la Inteligencia Artificial de Crehana
